Adam Gibbs
COSC 254 - Data Mining
Homework01 - Frequent Items

My implementation is in a jupyter notebook, frequent-items.ipynb.
-All cells have been run and the graphs should be present upon opening the file.
-If not, then something went wrong, and the entire notebook takes about 5 min to
 run on my laptop.
-All code, including those of the visualizations, are done in python.
-The first couple cells are very quick and just explain things briefly, and then 
 the exact and sampling algorithms are the next two cells and the first two cells of
 actual substance.
-The report is mixed into the notebook via markdown cells.
